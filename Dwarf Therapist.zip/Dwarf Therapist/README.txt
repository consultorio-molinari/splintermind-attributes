Dwarf Therapist v0.6.12
Copyright (c) 2009-2012 Trey Stout (chmod)
Homepage: http://code.google.com/p/dwarftherapist/
License: MIT License (see included LICENSE.txt file)

The author would like to thank the following people:
 - My wife for putting up with me spending so much time on this. HI HONEY!
 - Tarn & Zach Adams for one of the best games ever made 
   (http://www.bay12games.com/dwarves/)
 - Jan Kopcsek for the fantastic Dwarf Manager which inspired this project in 
   the first place (http://dwarfmanager.sourceforge.net/)
 - Mark James for the amazing Silk icon set 
   (http://www.famfamfam.com/lab/icons/silk/)
 - Paul Davey for the hammer icon (http://mattahan.deviantart.com/)
 - Killian Hermann for testing, brainstorming sessions, and general 
   support
 - Simon Poile for being a good patron of the arts ;)
 - The udpviper.com community for making me feel okay about writing so much 
   software.
 - The DF Community for their encouragement, time, and donations!
 
 Please See KNOWN_ISSUES.txt for up to date lists of known bugs
